# -DynoHandicap-V3.3-
# 🧠🐎 DynoHandicap V3.3 – Android Edition  DynoHandicap est un système intelligent d’analyse et de prédiction pour les courses hippiques. La version 3.3 marque une avancée majeure : elle est capable d’identifier le **type de course analysée** (âge, distance, terrain, discipline) et **d’adapter automatiquement ses pondérations stratégiques
